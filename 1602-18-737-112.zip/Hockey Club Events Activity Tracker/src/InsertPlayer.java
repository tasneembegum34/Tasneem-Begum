import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertPlayer extends Frame 
{
	Button insertPlayerButton;
	TextField p_idText, pfnameText, plnameText,positionText,rankText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertPlayer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertPlayerButton = new Button("Insert Player");
		insertPlayerButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{				  
				  String query= "INSERT INTO player VALUES(" + p_idText.getText() + ", " + "'" + pfnameText.getText() + "'" + ","+"'"+plnameText.getText() +"'"+ ","+"'"+positionText.getText()+"'"+","+ rankText.getText()+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		p_idText = new TextField(20);
		pfnameText = new TextField(20);
		plnameText = new TextField(20);
		positionText=new TextField(20);
		rankText = new TextField(20);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Player ID:"));
		first.add(p_idText);
		first.add(new Label("First Name:"));
		first.add(pfnameText);
		first.add(new Label("Last Name:"));
		first.add(plnameText);
		first.add(new Label("Position: "));
		first.add(positionText);
		first.add(new Label(" Rank: "));
		first.add(rankText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertPlayerButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Event Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertPlayer sail = new InsertPlayer();

		sail.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		sail.buildGUI();
	}
}



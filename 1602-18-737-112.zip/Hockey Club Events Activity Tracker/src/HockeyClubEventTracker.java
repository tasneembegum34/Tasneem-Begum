import java.awt.*; 
import java.awt.event.*; 

class HockeyClubEventTracker extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll,l2;
	  Frame f;
	  InsertAdmin iadmin; 
	  UpdateAdmin uadmin;
	  DeleteAdmin dadmin;
	  InsertEvents ievents;
	  DeleteEvents devents;
	  UpdateEvents uevents;
	  InsertPlayer iplayer;
	  DeletePlayer dplayer;
	  UpdatePlayer uplayer;
	  InsertTracks itracks;
	  DeleteTracks dtracks;
	  UpdateTracks utracks;
	  InsertParticipate iparticipate;
	  DeleteParticipate dparticipate;
	  UpdateParticipate uparticipate;
	  
	  HockeyClubEventTracker() 
	  { 
		    ll = new Label("Welcome to");
		    l2=new Label("Hockey Club Event Activity Tracker");
			ll.setAlignment(Label.CENTER);  
			l2.setAlignment(Label.CENTER);  
			ll.setFont(new Font("SansSerif", Font.BOLD, 40));
			l2.setFont(new Font("SansSerif", Font.BOLD, 50));
			setLayout(new BorderLayout());
			add(ll,BorderLayout.NORTH);
			add(l2,BorderLayout.CENTER);
		 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		
			Menu admin = new Menu("Admin"); 
			MenuItem item1, item2, item3; 
			admin.add(item1 = new MenuItem("Insert Admin")); 
			admin.add(item2 = new MenuItem("Update Admin")); 
			admin.add(item3 = new MenuItem("Delete Admin")); 
			mbar.add(admin);  
		 
			Menu events = new Menu("Events"); 
			MenuItem item4, item5, item6; 
			events.add(item4 = new MenuItem("Insert Events")); 
			events.add(item5 = new MenuItem("Update Events")); 
			events.add(item6 = new MenuItem("Delete Events"));  
			mbar.add(events); 
			
			Menu player = new Menu("Player"); 
			MenuItem item7, item8, item9; 
			player.add(item7 = new MenuItem("Insert Player")); 
			player.add(item8 = new MenuItem("Update Player")); 
			player.add(item9 = new MenuItem("Delete Player")); 
			mbar.add(player); 
			
			Menu tracks= new Menu("Tracks");
			MenuItem item10,item11,item12;
			tracks.add(item10=new MenuItem("Insert Tracks"));
			tracks.add(item11=new MenuItem("Update Tracks"));
			tracks.add(item12=new MenuItem("Delete Tracks"));
			mbar.add(tracks);
			
			Menu participate=new Menu("Participate");
			MenuItem item13,item14,item15;
			participate.add(item13=new MenuItem("Insert Participate"));
			participate.add(item14=new MenuItem("Update Participate"));
			participate.add(item15=new MenuItem("Delete Participate"));
			mbar.add(participate);
		
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this);	
			item11.addActionListener(this);	
			item12.addActionListener(this);	
			item13.addActionListener(this);	
			item14.addActionListener(this);	
			item15.addActionListener(this);	
					
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			setTitle("Hockey Club Event Activity Tracker "); 
			Color clr = new Color(150, 150, 150);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setSize(600, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 

		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Admin"))
		  {
			iadmin = new InsertAdmin();

			iadmin.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				iadmin.dispose();
			}
			});		
			iadmin.buildGUI();	
          }			
		 
		 else if(arg.equals("Update Admin")) 
		 {
			uadmin = new UpdateAdmin();
			uadmin.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uadmin.dispose();
			}
			});		
			uadmin.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Admin")) 
		 {
			dadmin = new DeleteAdmin();

			dadmin.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dadmin.dispose();
			}
			});		
			dadmin.buildGUI();		 
		 }
		 
		 else if(arg.equals("Insert Events")) 
		 {
			ievents = new InsertEvents();
			ievents.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ievents.dispose();
			}
			});		
			ievents.buildGUI();		 
		 }
		 else if(arg.equals("Update Events")) 
		 {
			uevents = new UpdateEvents();
			uevents.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				uevents.dispose();
			}
			});		
			uevents.buildGUI();		 
		 }	
		 else if(arg.equals("Delete Events")) 
		 {
			devents = new DeleteEvents();
			devents.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				devents.dispose();
			}
			});		
			devents.buildGUI();		 
		 }			 
		 else if(arg.equals("Insert Player")) 
		 {
			iplayer = new InsertPlayer();
			iplayer.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				iplayer.dispose();
			}
			});		
			iplayer.buildGUI();		 
		 }	
		 else if(arg.equals("Update Player")) 
		 {
			uplayer = new UpdatePlayer();
			uplayer.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				uplayer.dispose();
			}
			});		
			uplayer.buildGUI();		 
		 }
		 else if(arg.equals("Delete Player")) 
		 {
			dplayer = new DeletePlayer();
			dplayer.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dplayer.dispose();
			}
			});		
			dplayer.buildGUI();		 
		 }	
		 else if(arg.equals("Insert Tracks")) 
		 {
			itracks = new InsertTracks();
			itracks.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				itracks.dispose();
			}
			});		
			itracks.buildGUI();		 
		 }	
		 else if(arg.equals("Update Tracks")) 
		 {
			utracks = new UpdateTracks();
			utracks.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				utracks.dispose();
			}
			});		
			utracks.buildGUI();		 
		 }	
		 else if(arg.equals("Delete Tracks")) 
		 {
			dtracks = new DeleteTracks();
			dtracks.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dtracks.dispose();
			}
			});		
			dtracks.buildGUI();		 
		 }	
		 else if(arg.equals("Insert Participate")) 
		 {
			iparticipate = new InsertParticipate();
			iparticipate.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				iparticipate.dispose();
			}
			});		
			iparticipate.buildGUI();		 
		 }	
		 else if(arg.equals("Update Participate")) 
		 {
			uparticipate = new UpdateParticipate();
			uparticipate.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				uparticipate.dispose();
			}
			});		
			uparticipate.buildGUI();		 
		 }	
		 else if(arg.equals("Delete Participate")) 
		 {
			dparticipate = new DeleteParticipate();
			dparticipate.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dparticipate.dispose();
			}
			});		
			dparticipate.buildGUI();		 
		 }	
	  
	  
	  }
	  
	  
	  public static void main(String ... args)
	  {
			new HockeyClubEventTracker();	  
	  }
} 
 


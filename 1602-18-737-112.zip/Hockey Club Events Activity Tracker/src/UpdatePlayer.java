import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdatePlayer extends Frame 
{
	Button updatePlayerButton;
	List playerIDList;
	TextField p_idText, pfnameText, plnameText,positionText,rankText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdatePlayer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadPlayer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT p_id FROM player");
		  while (rs.next()) 
		  {
			playerIDList.add(rs.getString("p_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		playerIDList = new List(10);
		loadPlayer();
		add(playerIDList);
		
		playerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM player where p_id ="+playerIDList.getSelectedItem());
					rs.next();
					p_idText.setText(rs.getString("p_id"));
					pfnameText.setText(rs.getString("pfname"));
					plnameText.setText(rs.getString("plname"));
					positionText.setText(rs.getString("position"));
					rankText.setText(rs.getString("rank"));
					
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	   
		updatePlayerButton = new Button("Update Player");
		updatePlayerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE player "
					+ "SET pfname='" + pfnameText.getText() + "', "
					+ "plname='" + plnameText.getText() + "',"
					+"position='"+positionText.getText()+"',"
					+"rank="+rankText.getText()
					+  " WHERE p_id = "
					+ playerIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					playerIDList.removeAll();
					loadPlayer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		p_idText = new TextField(20);
		pfnameText = new TextField(20);
		plnameText = new TextField(20);
		positionText=new TextField(20);
		rankText = new TextField(20);
		

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Player ID:"));
		first.add(p_idText);
		first.add(new Label("First Name:"));
		first.add(pfnameText);
		first.add(new Label("Last Name:"));
		first.add(plnameText);
		first.add(new Label("Position: "));
		first.add(positionText);
		first.add(new Label(" Rank: "));
		first.add(rankText);
		first.setBounds(125,90,200,100);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updatePlayerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Player");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdatePlayer ups = new UpdatePlayer();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}


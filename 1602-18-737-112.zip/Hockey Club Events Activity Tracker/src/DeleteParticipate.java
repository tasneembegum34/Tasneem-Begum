import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteParticipate extends Frame 
{
	Button deleteParticipateButton;
	List participateIDList;
	TextField e_idText, p_idText, p_dateText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteParticipate() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadParticipate() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM participate");
		  while (rs.next()) 
		  {
			  participateIDList.add(rs.getString("e_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    participateIDList = new List(10);
		loadParticipate();
		add(participateIDList);

		participateIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM participate");
					while (rs.next()) 
					{
						if (rs.getString("e_id").equals(participateIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						e_idText.setText(rs.getString("e_id"));
						p_idText.setText(rs.getString("p_id"));
						p_dateText.setText(rs.getString("p_date"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	   
		deleteParticipateButton = new Button("Delete Event");
		deleteParticipateButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM participate WHERE e_id = "
							+ participateIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					e_idText.setText(null);
					p_idText.setText(null);
					p_dateText.setText(null);
					participateIDList.removeAll();
					loadParticipate();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		e_idText = new TextField(15);
		p_idText = new TextField(15);
		p_dateText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Event ID:"));
		first.add(e_idText);
		first.add(new Label("Player ID:"));
		first.add(p_idText);
		first.add(new Label("Participate Date:"));
		first.add(p_dateText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteParticipateButton);
        second.setBounds(125,220,150,100);         
		
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Participated player");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteParticipate dels = new DeleteParticipate();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}


import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteEvents extends Frame 
{
	Button deleteEventsButton;
	List eventsIDList;
	TextField e_idText, locationText, e_dateText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteEvents() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadEvents() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM events");
		  while (rs.next()) 
		  {
			eventsIDList.add(rs.getString("e_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    eventsIDList = new List(10);
		loadEvents();
		add(eventsIDList);
	
		eventsIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM events");
					while (rs.next()) 
					{
						if (rs.getString("e_id").equals(eventsIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						e_idText.setText(rs.getString("e_id"));
						locationText.setText(rs.getString("location"));
						e_dateText.setText(rs.getString("e_date"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		deleteEventsButton = new Button("Delete Event");
		deleteEventsButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM events WHERE e_id = "
							+ eventsIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					e_idText.setText(null);
					locationText.setText(null);
					e_dateText.setText(null);
					eventsIDList.removeAll();
					loadEvents();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		e_idText = new TextField(15);
		locationText = new TextField(15);
		e_dateText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Event ID:"));
		first.add(e_idText);
		first.add(new Label("Location:"));
		first.add(locationText);
		first.add(new Label("Event Date:"));
		first.add(e_dateText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteEventsButton);
        second.setBounds(125,220,150,100);         
		
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Event");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteEvents dels = new DeleteEvents();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}


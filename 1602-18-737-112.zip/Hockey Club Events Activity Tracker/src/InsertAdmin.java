import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.JOptionPane;
public class InsertAdmin extends Frame 
{
	Button insertAdminButton;
	TextField u_idText, fnameText, lnameText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertAdmin() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		insertAdminButton = new Button("Insert Admin");
		insertAdminButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{			  
				  String query= "INSERT INTO admin VALUES(" + u_idText.getText() + ", " + "'" + fnameText.getText() + "'" + ","+"'"+lnameText.getText() +"'"+ ")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				  JOptionPane.showMessageDialog(null,"Input is in wrong format.", "Error Message",JOptionPane.ERROR_MESSAGE);
				}
			}
		});

	
		u_idText = new TextField(15);
		fnameText = new TextField(15);
		lnameText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Admin/User ID:"));
		first.add(u_idText);
		first.add(new Label("First Name:"));
		first.add(fnameText);
		first.add(new Label("Last Name:"));
		first.add(lnameText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertAdminButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setTitle("New Admin Creation");
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertAdmin sail = new InsertAdmin();

		sail.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		sail.buildGUI();
	}
}


import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JOptionPane;
public class UpdateParticipate extends Frame 
{
	Button updateParticipateButton;
	List participateIDList;
	TextField e_idText, p_idText, p_dateText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateParticipate() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadParticipate() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT e_id FROM participate");
		  while (rs.next()) 
		  {
			participateIDList.add(rs.getString("e_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
		participateIDList = new List(10);
		loadParticipate();
		add(participateIDList);

		participateIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM participate where e_id ="+participateIDList.getSelectedItem());
					rs.next();
					e_idText.setText(rs.getString("e_id"));
					p_idText.setText(rs.getString("p_id"));
					p_dateText.setText(rs.getString("p_date"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
	
		updateParticipateButton = new Button("Update info of Player Participate");
		updateParticipateButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE participate "
					+ "SET p_id=" + p_idText.getText() + ", "
					+ "p_date='" + p_dateText.getText() + "'"
					+  " WHERE e_id = "
					+ participateIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					participateIDList.removeAll();
					loadParticipate();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
					  JOptionPane.showMessageDialog(null,"Input is in wrong format.", "Error Message",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		e_idText = new TextField(15);
		p_idText = new TextField(15);
		p_dateText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Event ID:"));
		first.add(e_idText);
		first.add(new Label("Player ID:"));
		first.add(p_idText);
		first.add(new Label("Participate Date:"));
		first.add(p_dateText);
		first.setBounds(125,90,200,100);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateParticipateButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Events");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateParticipate ups = new UpdateParticipate();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}


import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteTracks extends Frame 
{
	Button deleteTracksButton;
	List tracksIDList;
	TextField u_idText, e_idText, timeText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteTracks() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTracks() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM tracks");
		  while (rs.next()) 
		  {
			tracksIDList.add(rs.getString("u_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    tracksIDList = new List(10);
		loadTracks();
		add(tracksIDList);
		
		tracksIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM tracks");
					while (rs.next()) 
					{
						if (rs.getString("u_id").equals(tracksIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						u_idText.setText(rs.getString("u_id"));
						e_idText.setText(rs.getString("e_id"));
						timeText.setText(rs.getString("time"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
		deleteTracksButton = new Button("Delete track event");
		deleteTracksButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM tracks WHERE u_id = "
							+ tracksIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					u_idText.setText(null);
					e_idText.setText(null);
					timeText.setText(null);
					tracksIDList.removeAll();
					loadTracks();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		u_idText = new TextField(15);
		e_idText = new TextField(15);
		timeText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("User/Admin ID:"));
		first.add(u_idText);
		first.add(new Label("Event ID:"));
		first.add(e_idText);
		first.add(new Label("Track Time:"));
		first.add(timeText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteTracksButton);
        second.setBounds(125,220,150,100);         
		
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Event Tracked");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteTracks dels = new DeleteTracks();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}


import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JOptionPane;
public class UpdateAdmin extends Frame 
{
	Button updateAdminButton;
	List adminIDList;
	TextField u_idText, fnameText, lnameText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateAdmin() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:tasneem","tasneem","tasneem");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAdmin() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT u_id FROM admin");
		  while (rs.next()) 
		  {
			adminIDList.add(rs.getString("u_id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    adminIDList = new List(10);
		loadAdmin();
		add(adminIDList);
		
		adminIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM admin where u_id ="+adminIDList.getSelectedItem());
					rs.next();
					u_idText.setText(rs.getString("u_id"));
					fnameText.setText(rs.getString("fname"));
					lnameText.setText(rs.getString("lname"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
		updateAdminButton = new Button("Update admin");
		updateAdminButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE admin "
					+ "SET fname='" + fnameText.getText() + "', "
					+ "lname='" + lnameText.getText() + "'"
					+  " WHERE u_id = "
					+ adminIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					adminIDList.removeAll();
					loadAdmin();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
					  JOptionPane.showMessageDialog(null,"Input is in wrong format.", "Error Message",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		u_idText = new TextField(15);
		fnameText = new TextField(15);
		lnameText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Admin/User ID:"));
		first.add(u_idText);
		first.add(new Label("First Name:"));
		first.add(fnameText);
		first.add(new Label("Last Name:"));
		first.add(lnameText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateAdminButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Admin");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateAdmin ups = new UpdateAdmin();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}
